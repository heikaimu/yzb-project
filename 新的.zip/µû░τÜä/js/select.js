$(function() {
  $("#link-select").find('.input-wrapper').click(function() {
    $(this).next('.select-list').toggle();
  })
})